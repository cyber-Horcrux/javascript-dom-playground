# Contributing to JavaScript DOM Playground

First off, thanks for taking the time to look at this project! It started as a
personal learning exercise, so contributions from other learners (and
experienced devs pointing out better patterns) are very welcome.

## Ways to contribute

- 🐛 **Report a bug** — open an issue describing what you expected vs. what happened.
- 💡 **Suggest an improvement** — check the "Future Improvements" list in the
  README first; if your idea isn't there, open an issue to discuss it.
- 🔧 **Submit a fix or feature** — small, focused pull requests are easiest to review.

## Getting set up locally

This is a plain HTML/CSS/JS project — no build step, no dependencies.

1. Fork and clone the repository.
   ```bash
   git clone https://github.com/<your-username>/JavaScript-DOM-Practice.git
   ```
2. Open `index.html` directly in your browser, or serve it locally
   (e.g. with the VS Code "Live Server" extension) so changes reload automatically.
3. Make your changes in `index.html`, `style.css`, or `script.js`.

## Code style

- Use `camelCase` for variables and functions.
- Prefer `const`/`let` over `var`.
- Keep functions small and named after what they do (e.g. `initCounter`, not `doStuff`).
- Add a short comment above any function whose purpose isn't obvious from its name.
- Match the existing indentation (2 spaces).

## Commit messages

Write short, present-tense messages that describe *what* changed:

```
Add dark mode toggle
Fix counter not resetting on click
Update README with new screenshot
```

## Submitting a pull request

1. Create a branch: `git checkout -b fix/counter-reset`
2. Commit your changes with a clear message.
3. Push the branch and open a pull request against `main`.
4. Describe what you changed and why in the PR description.

## Code of conduct

Be respectful and constructive. This project is meant to be a friendly space
for people who are still learning — including the maintainer!
