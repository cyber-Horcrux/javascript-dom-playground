# Screenshots

Add a screenshot of the running app here as `project-preview.png`.

**How to capture one:**
1. Open `index.html` in your browser.
2. Resize the window to a normal desktop width (~1200px looks best).
3. Take a screenshot and save it as `project-preview.png` in this folder.
4. It will then appear automatically in the main `README.md`.
